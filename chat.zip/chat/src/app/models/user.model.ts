export class User {
    uid?: string;
    email?: string;
    username?: string;
    password?: string;
    status?: string;
}

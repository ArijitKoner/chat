declare var module: NodeModule;
interface NodeModule {
  id: string;
}

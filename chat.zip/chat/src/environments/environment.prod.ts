export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyA_MXm0opB-zd29wtNLZ9gcJQblI4Mm4TY',
	authDomain: 'chatapp-f0fa9.firebaseapp.com',
	databaseURL: 'https://chatapp-f0fa9.firebaseio.com',
	projectId: 'chatapp-f0fa9',
	storageBucket: '',
	messagingSenderId: '198934888798'
  }
};

# Chat

This is a simple chat application built using Angular  1.2.6.and Firebase.